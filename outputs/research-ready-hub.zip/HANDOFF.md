# REI — continuation handoff

## Consistent visual finish — 1 October 2026

Added visual-finish.css and visual-finish.js, loaded last in index.html. Shared typography, spacing, glass controls, tabs, focus states, forms, empty states, disclosure panels, research tables, dialogs and responsive wrapping now use one final layer. Notebook/proposal writing surfaces use ivory and readable ink; fixed competing legacy title/textarea colors and placeholder contrast. Notebook mobile sculpture shortened. Added polite note status, invalid-field semantics and keyboard-focusable named table regions only when they overflow. Existing storage and save workflows retained.

Verified 164 structural route checks: all 63 routes at 1440x960 and 390x844, plus 19 representative routes at 320x740 and 768x1024. No document horizontal overflow, missing main heading or duplicate IDs found. Visually inspected desktop/mobile notebook, mobile dialog and proposal. Checked required validation, notebook search reset, dropdown ArrowDown/Escape and focus return, Explore Escape/focus return, table keyboard region, saved fictional PDF rendering, mobile companion pane switching and closing. Captured warning/error logs empty. 25 top-level JavaScript syntax checks plus workbench-core, local-search and reader-regression passed; git diff --check passed. User-authored contents were not edited.

Evidence/report/screenshots and runnable rei-visual-finish.zip are in C:/Users/admin/Documents/Codex/2026-10-01/co/outputs. Route checks are structural, not exhaustive interaction tests. Physical devices, Firefox/Safari, full accessibility audit, OS reduced-motion emulation, low-end performance and backup restore remain unverified. No commit/push/deployment in this pass. Preview returned to notebook; viewport override reset. Existing runnable repository bundle refreshed.

## Observatory implementation — 1 October 2026

Implemented the researched direction locally. Replaced the earlier SVG research story with an original, lazy-loaded Three.js optical archive: machined lens, engraved bezel, orbiting source sheets, context-focused evidence view, connected argument assembly, and coordinated chapter captions. Desktop scroll advances four chapters; manual tabs and Arrow/Home/End controls remain available. Mobile uses manual chapters. A skip control preserves normal navigation and transfers focus to the next reading section. Refined hero transmission (opacity 1), dark transmission background, reflections and contextual inspection feedback. Added optical-observatory.css separately from the existing observatory.css; existing foundation stylesheet preserved.

Added optional companion desk in Reader and Proposal. Reader keeps the real local proposal beside the PDF/capture workflow; Proposal shows source-linked findings and allows explicit append into the existing draft. Existing DOM controls are moved, not cloned, preserving handlers and PDF state. Desktop separator supports pointer drag, Left/Right and Home/End, with width preference stored locally. Mobile/tablet has a single-pane switch. Closing restores project navigation. Ivory writing surface and restrained warm accents complement the charcoal/chrome system. No new framework, external asset requests, accounts, schema changes or paid service. Corrected Synthesis ordering in shared project transitions.

Verified: bundled Node syntax checks for new/changed scripts; workbench-core, local-search and reader-regression tests; git diff --check. In-app browser: local PDF opened alongside proposal; fictional companion draft and source-linked insertion persisted after reload; fictional QA draft restored afterward; separator ArrowLeft changed 60 to 58; close restored navigation; chapter click/End keyboard, native scroll progression and inspection feedback worked; motion pause made story non-sticky and was restored. 390px home/story/Reader/Proposal and 768px companion checked without document horizontal overflow; desktop checked at 1440x960. Native browser skip action preserved #home and focused the next reading heading. Browser captured warning/error logs empty at inspected checkpoints. User research was not edited. The original QA fixture remains local.

Limits: Firefox/Safari, screen-reader audit, OS reduced-motion emulation, real touch and low-end GPU testing, field Core Web Vitals, complete-backup download/restore and full all-route regression remain unverified. The story uses clearly labeled illustrative sheets, not live project data. The actual companion desk uses local project data. No commit, push or deployment performed in this pass. Current browser preview is http://127.0.0.1:4187/#home. Runnable bundle refreshed; public Vercel remains the previously deployed version.


## Optical Research Atelier enhancement — 1 October 2026

Added atelier-home.js, atelier.js and atelier.css. Original interactive research story transitions between question, sources, evidence and argument, with glass instrument, silver orbit lines and restrained violet accents. Arrow/Home/End tab keyboard behavior and real destination links. Orbit pauses offscreen and honors motion preference. Navigation directory now previews focused/hovered destinations. Research desk gets reversible focus mode and a live Markdown-heading outline with jump-to-heading selection in the proposal editor. Refined hero typography and optical interaction hint. Existing 3D magnifying-glass controls, all routes and local storage preserved.

Validation: syntax checks and existing workbench-core, reader-regression and local-search tests passed; git diff --check passed. Browser optical stage selection and ArrowRight checked. 390px optical story showed no horizontal overflow. Motion pause resulted in animationName none and was restored. Focus room concealed project rail and restored through Show project navigation. Fictional proposal headings appeared in outline; Methods selected the corresponding heading in the editor. Directory preview updated on keyboard focus. No user-authored research changed; existing fictional QA proposal was updated with test headings. Full cross-browser, backup restore and performance benchmarking remain unverified as documented in stage 4. No commit, push or public deployment.


## Stage 4 — final polish and targeted regression

# REI final design pass — 1 October 2026

All four design stages are implemented locally. No commit, push or public deployment was performed.

## Final changes
- Brought the notebook, proposal draft and readiness surfaces into the glass/chrome design system.
- Unified visible focus outlines, disabled controls, editor typography and mobile form spacing.
- Removed overlapping learning entrance animations and tilt on large resource rows.
- Fixed the PDF reader's malformed saved-page key and cleanup failures when reopening documents.
- Added a targeted PDF regression test for page persistence, bounds, extracted text and cleanup variants.

## Verified
- Syntax checks for the changed design, application and research scripts.
- Workbench-core, local-search and reader-regression tests pass; whitespace checks pass.
- Saved local PDF fixture renders with selectable text and reopens successfully.
- Keyboard Enter opens the directory; Escape closes it and returns focus to Explore REI.
- Keyboard motion toggle works and paused preference survives reload; motion restored afterward.
- At 390px: homepage, academy, journey, toolkit, workshops, notebook, draft, readiness and lesson writing had no document horizontal overflow.
- Tablet notebook at 768px had no document horizontal overflow.
- Stage 3 previously checked all nine research routes on desktop/mobile and fictional local source, evidence and proposal persistence.
- Final captured browser error logs were empty.

## Verification limits
- Complete-backup export was clicked, but the browser download event timed out. Completed download and restore were not verified.
- OS reduced-motion emulation, full screen-reader audit, every keyboard/form state, real touch devices, Firefox/Safari and low-end performance benchmarking were not completed. Implemented safeguards are not formal accessibility/performance certification.
- QA uses the explicitly fictional design project and local PDF fixture; user research was not edited. Local browser storage was preserved.

Preview: http://127.0.0.1:4187/#home



## Stage 3 — contextual research desk (2026-10-01)

Added research-room.css and research-room.js. Replaced the horizontal project tabs with a numbered, sticky glass sidebar on desktop and a two-column destination menu on mobile. All nine destinations, real routes, forms and storage contracts remain. Applied optical surfaces, typography, readable editors, restrained section entrances and disclosure animations to projects, Library, Reader, Evidence, Claims, Synthesis, Design, Map, Proposal and Review. Corrected inherited content width and heading centering. New animations cancel on motion pause and route changes; editors are not animated.

Verified bundled Node syntax for changed research scripts; existing workbench-core and local-search tests passed; git diff --check passed. Browser opened all nine destinations and confirmed active sidebar destinations. Mobile 390px inspected all nine with no document horizontal overflow. Fictional design QA project saved a source, source note, evidence note and proposal; evidence persisted after reload, source note and proposal survived navigation. Browser captured error logs were empty. QA data is explicitly fictional and remains only in the existing local preview QA project. No user-authored research modified. Reader UI checked; attaching/rendering a PDF, full exports/restores, keyboard, screen reader, cross-browser and performance checks remain for stage 4.

Stages 1-3 implemented as local previews. Stage 4 final polish/regression remains. No commit, push or deployment for this design pass.


## Stage 2 — editorial learning rooms (2026-10-01)

Added learning.css and learning.js, scoped to academy, journey, toolkit, workshops, lessons and resource/session guides. Larger sans-serif hierarchy; editorial lesson rows; sequential phase sections; stacked workshops; glass filter/step controls; readable writing surfaces; contextual edition navigation; cancellable scroll entrances. Existing particle illustrations, routes, draft handlers and local storage retained. Motion preferences respected; pause cancels new entrance animations. No new dependency or paid service.

Verified: bundled Node syntax and existing workbench-core/local-search tests passed; git diff --check passed. Browser academy search/phase filter, toolkit Evidence filter, lesson Learn/Example/Write/Check transitions, correct quiz feedback and workshop/resource guide navigation checked. Mobile 390px horizontal overflow absent on inspected academy, journey, seminars, workshop guide, lesson writing, toolkit and resource guide. Motion toggle set off and was restored. Draft textarea present with expected stage binding; full autosave/download/export, all lesson states, keyboard, cross-browser and performance regression remain for stage 4. QA answered lesson 4 check on the local preview origin; no user draft text modified. No commit, push or deployment.

Next: stage 3 research workspace and contextual sidebar. Stage 4 full polish and regression. Stage 1-2 are local previews, not a verified public release.


## Stage 1 — realistic optical instrument and richer motion

Rebuilt the hero as a magnifying glass with beveled annular metal housing, curved glass, grip, collar and reflective trim. Added mouse drag plus Rotate/Inspect/Reset controls, enlarged inspection, pointer response and scroll transformations. Added dream-polish.js for menu stagger, button ripples and scroll parallax, alongside hover border sweeps and link movement. Referenced user-approved motion libraries without importing React or copying premium source. Desktop drag and controls and mobile 390px/no-overflow inspected; no console errors observed. Syntax, existing workbench-core/local-search tests and whitespace checks passed. Full cross-browser/performance/accessibility regression remains stage 4. Stages 2–4 remain unimplemented in this pass.

## Stage 1 refinement — lens identity

User approved the overall direction but rejected the knot sculpture and logo. Replaced both with a glass research lens and connected points, including SVG logo fallback and favicon. Retained pointer/scroll response and particles. Syntax/whitespace checks passed; desktop scene inspection showed no console errors. Four total redesign stages remain the agreed structure.

## Design continuation — 2026-10-01: Dream Laboratory, stage 1

Approved direction: original immersive redesign in stages, charcoal/silver/liquid chrome, glass plus evolving particles, oversized clean sans-serif, minimal header and full-screen navigation, expressive motion across the site. Keep REI logo and all working research features/storage. Mobile retains rich visuals within device capacity. Optional ambient sound starts off. Reference direction: Alche and GetLayers; exact MotionUI/Lumen references remain unconfirmed.

Implemented stage 1:
- New original homepage composition with oversized typography, editorial sections, connected-space links, and existing learning/progress destinations.
- Locally rendered Three.js chrome form with glass orbital lenses and surrounding particles; responds to pointer and scroll, uses a generated reflection environment and CSS fallback, and disposes resources on route changes.
- Minimal global header and full-screen glass directory retaining existing destination search and Ctrl/Cmd K navigation.
- Shared glass buttons, inputs, dropdowns, optical hover highlights, magnetic homepage CTAs, tilted particle illustrations, entrance/reveal animations, and desktop cursor accent.
- Glass dropdowns preserve underlying native select/form state and existing change handlers. Arrow keys, Enter, Escape, Tab and type-ahead supported.
- Local synthesized ambient sound with explicit on/off control; starts off each page load and fades when page is hidden. No external audio assets or requests.
- Motion pause/reduced-motion support, offscreen scene pause, 30fps scene budget and capped rendering resolution.

Validation actually completed:
- Syntax checks for dream.js, dream-home.js and app.js; existing workbench-core and local-search tests passed; git diff --check passed.
- In-app-browser desktop and 390x844 mobile homepage inspected, WebGL scene rendered, no horizontal overflow in inspected homepage states.
- Full-screen menu opened/closed on desktop and mobile; directory search for methods returned three results and concealed the directory grid.
- Starter-template dropdown opened, ArrowDown + Enter selected Literature review and updated the underlying native selection.
- Animation pause toggled document motion state. Audio on/off UI toggled and reset to off on reload; audio fidelity was not independently assessed.
- Fictional project created and reopened in Library with saved-on-device status; local browser error logs were empty in inspected routes.
- Mobile sculpture/copy overlap fixed during visual review.

Remaining: user review of stage 1; public-page/lesson layout redesign; contextual research sidebar and full reader/evidence/claim/synthesis/design/proposal/review redesign; lower-page full regression; OS reduced-motion emulation, full keyboard/touch, low-end-device performance, Safari/Firefox, audio fidelity and complete storage/export regression. Do not claim the whole website redesign or formal accessibility/performance certification is complete. No commit, push or deployment performed for this design stage.

Files: dist/dream-home.js, dist/dream.js, dist/dream.css, integration in dist/app.js and dist/index.html; approved direction in design-system/rei-dream-laboratory/MASTER.md. Prior local-search changes are retained.


## Continuation update — 2026-10-01: local workspace search

Implemented a read-only search panel on the research project overview. It searches project questions, source metadata and reading notes, evidence passages and findings, claims, decisions, proposals, learning notebook notes, and lesson drafts. Workspace and content-type filters, excerpts, section links, empty-state guidance, and a polite result-count announcement are included. Results are capped at 100 visible entries with refinement guidance. Search operates in this browser without accounts or network requests.

Files: `dist/local-search.js`, integration in `dist/research.js` and `dist/index.html`, and `tests/local-search.cjs`.

Validation: local-search tests and existing workbench-core tests passed; syntax checks for both changed scripts and git diff whitespace checks passed. Browser visual, keyboard, mobile, and large-project performance checks have not been completed in this continuation. Links open the relevant section; they do not focus an individual record. Unsaved forms and PDF binary contents are not indexed. Workspace filters currently group projects with identical titles.

Changes are local and have not been committed, pushed, or deployed in this continuation. Next: verify browser interaction and performance, then consider individual-record navigation and project-ID-based filters. Preserve the free/local-first product direction.


## Current continuation update — 2026-09-25: research depth pass

The latest work is pushed to `master` through commit `ddb11e7`. The repository is clean and synchronized with `https://github.com/hoshixdd/REI`.

### Implemented since the previous handoff

- Research form drafts survive switching between project sections and restore with a visible local-draft message. Successful submission clears the draft.
- PDF restore validates attachment ownership, data URL format, PDF signatures, and stages records before IndexedDB writes.
- The PDF reader remembers the last page separately for each project and paper.
- Mobile research navigation remains visible while scrolling.
- Research progress feedback shows the four foundational areas: sources, evidence, proposal, and research design.
- The research argument debugger adds transparent prompts for unsupported claims, one-note claims, unlinked evidence, unresolved challenging evidence, incomplete comparisons, proposal text without claims, and missing design fields. These are prompts, not scientific scores.
- Evidence notes now support researcher-authored source-quality context: study type, sample or material, transferability or boundaries, conflicts or funding, and confidence in the interpretation.
- Research Design includes a separate readiness map for question clarity, source coverage, evidence traceability, method alignment, ethics planning, feasibility, proposal coherence, and review readiness.

### Current validation

- `tests/workbench-core.cjs` passes after the research-depth changes.
- `node --check` passes for the changed research and workbench modules.
- The repository is clean and pushed to GitHub.
- Full Playwright browser suites remain environment-blocked because browser automation hangs in the current restricted runtime. Do not claim those suites passed.

### Next implementation order

1. Cross-project local search across papers, passages, findings, claims, decisions, proposals, notes, and lesson drafts.
2. Synthesis matrix and thematic coding tools.
3. Review modes with unresolved actions for evidence, methods, ethics, and supervisor feedback.
4. Rich exports: evidence matrix, claim graph, source audit, decision journal, and supervisor packet.
5. Toolkit resource progress tracking.
6. Broader mobile, accessibility, and cross-browser QA.

### Product direction

REI should compete through transparent research reasoning rather than paid discovery or automatic scoring. Keep the evidence chain visible: question → claim → evidence note → exact passage → source → limitation. Preserve researcher control, fictional or non-personal test data, explicit consent, teacher or supervisor review, and no automatic scientific judgment.

Cloud accounts, sync, live provider discovery, AI extraction, OCR, collaboration, citation services, and AR/VR remain future work requiring external service or plan decisions.

## Current handoff — 2026-09-22: free research workbench

This section is the current source of truth; older sections below describe historical releases. The user requested immediate publication of the current version and a continuation handoff. The broader innovation roadmap is not complete.

### Product and cost constraints

- Product name: REI. Repository: https://github.com/hoshixdd/REI (master). Production: https://rei-pink.vercel.app/.
- Stay on the free/local-first path. No required paid APIs, AI subscriptions, or cloud accounts were added. No keys or credentials are needed for the new workbench.
- Preserve the interactive particle direction, glass logo, and recently shortened transitions. The user rejected solid decorative sculptures and crowded/high-force particles.
- Existing learning lessons, notebook, toolkit, and research functionality remain. Research data is separate from the learning notebook.

### What this version adds

Project navigation now includes Library, Reader, Evidence table, Claims, Research design, Literature map, Proposal studio, and Review & history.

1. CSV, RIS, and basic BibTeX imports with preview, selection, duplicate DOI/title exclusion, and library/bibliography exports. Complex BibTeX macros are not expanded.
2. Local PDF attachment and rendering using vendored Mozilla PDF.js 6.3.289. Page navigation, extracted selectable text, and passage capture with a PDF page locator. Exact quotations remain separate from researcher interpretations. No OCR; scanned PDFs may have no extractable text. Selection operates in the extracted text panel, not an overlay on the PDF image.
3. Claims with supporting/challenging/mixed/uncertain evidence links, editing, review state, and insertion into the proposal with source details and stable evidence IDs. Linked evidence cannot be removed until unlinked from claims/comparisons.
4. Objectives, measures, collection methods, analysis plans, and alignment rationales. Transparent completeness checks; these do not assess scientific validity.
5. Collection coverage table and manually authored comparisons of two evidence notes. These cannot establish that a gap exists in the entire literature.
6. Expandable question/claim/evidence/source outline above the existing citation map. This is an accessible project model, not a full spatial/VR digital twin.
7. Defense rehearsal prompts, decision journal, search log, and the latest 20 proposal/question snapshots. Changing the research question creates a snapshot and requests a design review. Draft restoration saves the current draft first.
8. Markdown review package, standalone readable HTML review, storage estimates, optional persistent-storage request, and complete JSON backup/restore including PDFs.

### Files and storage

- `dist/workbench-core.js`: pure import parsing, duplicate planning, workbench normalization/validation, completeness checks, bibliography.
- `dist/workbench.js`: feature views and event handling, PDF lifecycle, attachment storage, exports, and integration API.
- `dist/workbench.css`: responsive workbench layouts using existing REI styling.
- `dist/research.js`: original project store and routes; calls the workbench extension. `persist` clones the selected project before asynchronous writes.
- `dist/index.html`: loads core and workbench before research/app; asset token `rei-workbench-20260922`.
- `dist/vendor/pdfjs/`: local PDF.js module/worker, CMaps, fonts, WASM, and license. Lazy loaded when a PDF is opened. No runtime CDN needed.
- IndexedDB `rei-research` / `projects`: project records. `project.workbench.version = 1` holds new records.
- IndexedDB `rei-documents` / `files`: PDF blobs keyed by project ID and paper ID. Normal project JSON backups exclude PDFs; Review & history offers complete backups.
- Limits: 5 projects, 200 sources/project, 2 MB reference imports, 20 MB/PDF, 60 MB attachments/project, 100 MB backup restore input. Browser storage can still be cleared; keep external backups.
- Localhost and Vercel use different browser storage. Restoring creates a separate project; existing projects are not overwritten.

### Validation actually completed

- `tests/workbench-core.cjs` passed: quoted/multiline CSV, RIS authors/year, nested BibTeX, malformed imports, duplicate planning, broken evidence-link validation, PDF attachment validation, and missing design fields.
- Browser QA on a fictional local test project: imported two distinct sources while excluding a duplicate; rendered a locally generated PDF; extracted text; saved passage/page/finding; created a claim; linked evidence; inserted it into a proposal; saved a complete objective and methods plan; saved rehearsal answer and milestone; checked storage feedback.
- Exported complete JSON backup to Downloads, validated its contents with the core validator (2 sources, 1 evidence note, 1 claim, 1 objective, 2 snapshots, 1 PDF), restored as a separate project, and reopened the restored PDF successfully.
- Reader layout at 390px: one-column layout and no horizontal overflow. Console error checks passed on the inspected workflow.
- All-section mobile QA was interrupted after a browser-control timeout while moving from Evidence to Claims. Do not describe the entire mobile suite as passed. No full end-to-end automated browser suite was run in this pass.
- The readable HTML review export was implemented after the backup check and still needs a dedicated visual/export check. PDF text-selection capture button, comparisons, deletion guards, draft restore, reduced-motion traversal, and large/complex PDF cases need further dedicated QA.

### Continue here next

1. Resume QA with a local server and a fictional test project. Test remaining mobile sections, import variants, evidence unlink/remove guards, two-note comparisons, snapshot restore, and both review exports. Check keyboard navigation and reduced motion.
2. Improve recovery of partially completed forms when switching views; most forms currently save on explicit submission. Proposal and paper reading notes retain existing autosave behavior.
3. Strengthen attachment lifecycle/concurrency tests (switching sources/routes while reading, replacement, quota failures, malformed backups) and large-project performance checks before increasing limits.
4. Build on this working evidence-to-proposal foundation. Live discovery, Supabase accounts/sync, collaboration, AI extraction/chat, OCR, formal citation-style formatting, automatic contradiction detection, and full AR/VR/presentation modes are NOT implemented. Existing free setup scaffolding does not mean a backend is connected.
5. Keep the handoff truthful about what is implemented versus the broader roadmap. Never label completeness checks as a scientific quality score or claim reviewed-collection gaps prove novelty.

### Run and deploy

Static vanilla JS application; no build or npm installation is required. Serve `dist` locally on port 4173 with Python. Run `node tests/workbench-core.cjs` and `node --check` on changed scripts. `vercel.json` deploys `dist` directly; pushing master triggers the existing Vercel integration. Verify live asset contents after deployment rather than assuming a successful push means the site updated.

The tracked `outputs/research-ready-hub.zip` is a historical filename for the current distributable and is refreshed with this release. Test fixtures and scratch scripts under `work/` are ignored and are not shipped.

---


## Motion and particle tuning - 2026-09-21

- Shortened page arrivals to 300ms and chapter transitions to 220ms, removed full-screen blur and the two-frame route delay, and paused decorative rendering during navigation.
- Reduced shared particle fields from 16,000 to 8,000 points, lowered hero rendering density, pulled the illustration camera back, and reduced point size for more breathing room.
- Narrowed cursor influence and softened hover/press displacement. Distinct forms, pause controls, and reduced-motion support remain.
- Verified JavaScript syntax, whitespace, Journey graphics, Academy/Toolkit navigation cleanup, no desktop horizontal overflow, and no console errors on inspected routes. Device-wide performance benchmarks were not run.


## Particle revision — 2026-09-21

The user rejected the solid illustrative sculptures. Keep the REI glass logo but use original particle graphics throughout the product. References are luminous flowing wave images, not assets to copy.

- Replaced solid illustrations with a shared 16,000-point shader: twelve form families including ribbons, galaxies, wave terrain, helixes, vortices, braided loops, fountains and constellations. Major components get distinct numeric variants: homepage 0–2, Journey 3–5, Academy lessons 10–18, Toolkit resources 20–25, separate destination/workspace/detail variants.
- Cursor proximity repels points in the screen plane. Press produces an additional dispersal burst; movement eases back. Touch pointer events retain normal scrolling. Reduced motion and global pause suppress interaction animation.
- Hero's solid nucleus is hidden and its particle repulsion is stronger. Glass brand mark stays separate. Added a locally generated particle SVG fallback.
- Fixed legacy selector specificity that shrank destination artwork into a fraction of its intended width. Preserved the improved layouts.
- Navigation uses a flowing dotted wake and softer camera arrival. Resource/lesson entry can share the particle illustration between surfaces; route mounting waits two frames before capture. Reduced-motion path remains immediate.
- Checked desktop shader rendering, visible press dispersal, unique Academy/Toolkit/Journey variant assignments, resource transition cleanup (zero leftover names), motion toggle, 390px mobile layout (no horizontal overflow), and console logs (no errors in inspected routes). JavaScript syntax/whitespace checks passed. Full automated regression was not rerun. No deployment in this pass.


## REI identity and sculptural graphics — 2026-09-21

- Rebranded header, footer, page titles, about/backup descriptions, directory, transition label, and draft illustration to REI. Existing storage keys and backup schema stay compatible.
- Added an original animated glass knot logo with a matching SVG fallback/favicon.
- Replaced phase wire diagrams with real Three.js sculptures: interwoven lens, optical ring stack, beveled proposal layers. Used across homepage pathways, Academy, Journey, Toolkit and destination/lesson headers; Research Studio entrance also has a sculpture.
- Shared offscreen WebGL renderer paints only visible illustrations at a capped 20 fps. Locally generated environment reflections; no external asset requests. Global pause, reduced-motion preference, hidden-tab checks, and pointer tilt supported. Hero keeps its existing independent interactive renderer.
- Toolkit is now a numbered editorial catalogue with purpose, output, editable format, exploration link, and download. Search/filter and empty states preserved.
- Resource links participate in the clicked-surface cinematic transition. Fixed graphic-container sizing, mobile composition, wordmark specificity, and an encoded footer arrow.
- Manual browser checks: desktop Toolkit/Journey/lesson screenshots; mobile Toolkit/lesson/check at 390px; Toolkit Evidence filter, search and empty states, resource navigation; Academy Creation filter; motion toggle; no console errors in inspected routes; inspected routes had no horizontal page overflow. Syntax and git whitespace checks passed. Full automated regression has NOT been rerun.
- Taste and Impeccable were requested but not found in installed skill folders; applied installed UI/UX Pro Max plus the user's Studio workflow. No claim those missing skills were used.
- New source: `dist/sculptures.js`, `dist/rei.css`, `dist/rei-mark.svg`. All geometry and reflection assets are original code; bundled Three.js license remains unchanged.
- Local preview http://127.0.0.1:4173/ . Vercel has not been updated by this pass.


## Start here
The user explicitly requested the UI/UX Studio workflow and a full-product spatial redesign using Three.js and React Three Fiber as references. No homepage artwork is protected from improvement. Avoid repeated card grids; prioritize clear learning workflows, editorial composition, purposeful motion, and responsive accessibility. This is a browser-based spatial interface, not a headset AR/VR application.

## Current local Studio pass — 2026-09-20
- New `dist/studio.css` owns the final layout layer: open homepage, editorial pathway chapters, indexed Academy, continuous Journey, resource lists, workshop agendas, quieter lesson surfaces, and research/editor layouts.
- `dist/universe.js` now uses original intersecting physical-material rings, a faceted core, edge cage, and instanced satellites with the existing interactive particle field. No external model assets or React dependency added. Bundled Three.js licensing remains in place.
- Cinematic routing work is local: clicked-surface transitions, directional lesson/project steps, async research mounting, rapid-navigation cleanup, and reduced-motion fallback.
- Latest published version remains `f1f0232` at https://rei-pink.vercel.app/. This Studio pass is NOT committed or deployed.
- Validation this pass: JavaScript syntax checks passed for app, universe, spatial, motion. Desktop Academy/workshop and mobile home/writing-page screenshots inspected; mobile width checked at 390px; workshop and mobile routes showed no horizontal page overflow. This is targeted visual inspection, not a full regression pass.
- The cinematic QA test passed before this Studio pass. A subsequent elevated research QA command was blocked by automatic approval review because workspace credits were exhausted. Do not represent that rerun as passed or bypass the blocked approval. Full interaction regression and publishing remain pending.
- Next: complete route-wide visual/interaction QA when approval access is restored, review final visuals with the user, then commit and push to the existing GitHub remote. Keep current local user data intact.


## Project and preview
- Source: `dist/` — vanilla HTML/CSS/JavaScript, no build step.
- Serve: `python -m http.server 4173 --bind 127.0.0.1 --directory dist`
- Preview: http://127.0.0.1:4173/#home
- Existing browser tab may still show an older loaded version; reload to load the latest changes.
- User data is in browser localStorage `rrh-v2`; preserve its schema and migration from `rrh-v1`.
- Motion preference: `rrh-motion`.
- Latest downloadable bundle and README: `outputs/`.

## Implemented
- Homepage: interactive particle atlas with three phases, custom GPU morphs, pointer response, asymmetric sections, workspace illustrations.
- Nine lessons now have FOUR separate routes each:
  - `#lesson/0` (Learn; indexes 0–8)
  - `#lesson/0/example`
  - `#lesson/0/write`
  - `#lesson/0/check`
- Saved exercise drafts persist between pages; correct quiz plus nonempty draft enables completion.
- Six resource detail pages: `#resource/proposal`, `matrix`, `search`, `framework`, `methods`, `checklist`.
- Three dedicated workshop pages: `#workshop/0` through `2`.
- Notebook, proposal studio, readiness review with distinct headings and descriptions.
- Spatial page transitions using View Transitions when supported; fallback animation and reduced-motion handling. Rejected transition-ready promises on rapid navigation are handled.
- Live WebGL graphics on inner-page headers: particle sphere, spiral, helix, terrain field, lattice. One renderer per route; disposal on navigation.
- Explore hub directory (bottom-left button or Ctrl/Cmd+K), native dialog keyboard handling, Escape close.
- Lesson focus-reading mode, retained through lesson navigation in the session.
- Existing notes CRUD, unfinished note recovery, undo, JSON backup/restore, Markdown exports, six downloads, 27 readiness checks.

## Source map
- `app.js`: routing, page templates, storage, notes, lesson workflow, downloads/dialogs.
- `data.js`: substantive course content, resources, further reading.
- `universe.js`: custom Three.js particle shaders and lifecycle.
- `motion.js`: entrances, reveals, motion preferences.
- `atlas.js`: homepage phase controls; old in-page lesson navigation is skipped when new lesson flow exists.
- `spatial.js`: page transitions, purpose-specific headings, inner-page scene attachment.
- `navigation.js`: spatial directory and reading focus mode.
- CSS loads in order: `styles.css`, `future.css`, `observatory.css`, `spatial.css`. These layers reflect successive design passes. Consolidation is worthwhile later, but preserve the tested appearance.
- `vendor/`: locally bundled Three.js 0.180.0 and MIT license.
- `fonts/`: local fonts and licenses; no external runtime font service.

## Validation completed
- 36 lesson routes and 36 route/viewport combinations at 375, 768, and 1440 px.
- Four-step lesson workflow, quiz completion, resource download, draft persistence.
- Missing-draft completion redirects to writing; browser Back/Forward work.
- Enlarged text layouts and keyboard navigation.
- Reduced motion and persistent motion preference; paused scene verified stable after transitions settle.
- Directory keyboard shortcut, navigation/close, mobile dialog, Escape.
- Focus reading mode and draft persistence through step navigation and browser history.
- No page errors in latest `spatial-edge.cjs`, `spatial-qa.cjs`, and `production-qa.cjs` runs.
- Earlier full regressions covered notebook CRUD/undo, backup restoration, filters/search, all downloads, readiness persistence, legacy migration.

QA scripts and screenshots remain locally under ignored `work/`; key portable scripts are copied into `tests/`. Scripts expect Playwright; set PLAYWRIGHT_MODULE if it is not installed normally. Run from the repository root with the preview server active. Desktop screenshot files in tests default to `work/`, so create that directory first.

## Remaining production work
- This is a LOCAL application, not a launched SaaS. Accounts, backend, cloud sync, AI services, real seminar recordings, and WebXR are not implemented.
- Do a fresh visual pass on all inner pages with the user. Latest mobile/layout tests passed, but no claim of formal accessibility certification or all-browser compatibility.
- Consolidate layered CSS and the lesson template adapter when useful; avoid a gratuitous framework rewrite.
- Test Safari/Firefox and low-end mobile performance before public launch.
- Deployment remains separate. A previous Sites source upload was denied by automatic approval review; do not bypass that block. GitHub saving is already configured and successful at https://github.com/hoshixdd/REI; a GitHub push does not deploy the website.
- Do not upload `work/`, browser profiles, local test backups, credentials, or private user data.

## GitHub handoff
The user created https://github.com/hoshixdd/REI and authorized commits and pushes there. Origin is https://github.com/hoshixdd/REI.git and the active branch is master. The website, tests, README, downloadable bundle, and handoff are saved locally and pushed. Latest implementation commit: c823d73 (Give lesson pages a distinct research fieldnotes identity), following 7865ae5 (search and exact-step resume). This handoff update is a separate documentation commit. Continue from this repository and preserve saved-work compatibility. Do not create another repository or configure another account.

## Search and resume update
- Explore hub now searches 26 real destinations: eight spaces, nine lessons, six resources, and three workshops. Empty search shows the original spatial directory.
- Keyboard: Ctrl/Cmd+K opens navigation and focuses search; Arrow Down enters results, arrows navigate, Enter opens a result, Escape closes the dialog.
- Academy resume panel returns to the exact lesson step. Optional validated `resume: { lesson, step }` is saved in `rrh-v2` and included in JSON backups; older backups remain supported.
- Lesson flow tabs show saved word counts and whether the answer has been checked correctly.
- `continuity.js` implements search and resume presentation. Regression: `tests/continuity-qa.cjs`.

## Latest visual refinement
- Research Fieldnotes lesson identity: editorial numbered reading sections, contrasting example spreads, a light writing studio, and split-screen knowledge checks with live particle graphics. Responsive layouts retain keyboard-accessible answer controls and existing motion preferences.
- Verified all 36 lesson routes, draft and quiz workflow, back/forward navigation, and five enlarged-text layouts; inspected settled desktop and mobile views.
## Current checkpoint — 20 September 2026
- Latest user request: update and commit this handoff so the next session knows where the project stands. No additional website changes are part of this documentation checkpoint.
- Local project: `C:/Users/admin/Documents/Codex/2026-09-19/lets`. The browser currently points at `http://127.0.0.1:4173/#home`. Restart the static preview server if it is no longer running.
- The most recent design pass is implemented across all nine lessons, through shared templates in `dist/app.js` and scoped styles in `dist/spatial.css`. It adds the Research Fieldnotes masthead, numbered editorial sections, connected step navigation, a contrasting example spread, a pale writing surface, and a dark/light review composition with a live particle scene.
- Homepage appearance was preserved in that pass. Other destinations retain their earlier spatial designs; the Fieldnotes treatment has not yet been extended throughout the entire hub.
- Latest pass verification: `tests/spatial-qa.cjs` and `tests/spatial-edge.cjs` passed. Settled desktop Check/Write views and mobile Check were visually inspected. Earlier search/focus/workspace validation is described above; do not imply every historical test was rerun after this visual change.
- `outputs/research-ready-hub.zip` and its README were refreshed in c823d73. The root handoff is the continuation reference in GitHub; the ZIP is the runnable website bundle.
- The user has not yet reviewed or approved this latest design. Do not describe it as finished production SaaS or as satisfying their visual expectations without further feedback.

## Recommended continuation
1. Read this handoff, inspect Git status, and open the current preview before changing anything. Preserve existing user edits and local-storage compatibility.
2. Get the user's reaction to the Fieldnotes direction. If asked to continue visual work, improve the composition and identity of Academy, Journey, Toolkit/resource guides, workshops, and workspace surfaces while keeping content readable and giving each destination a clear purpose.
3. Prefer purposeful interactive graphics and connected transitions over adding decorative cards or indiscriminate motion. Keep reduced-motion controls, keyboard access, mobile usability, and draft saving intact.
4. Verify the affected workflows and responsive layouts, update the runnable ZIP when website files change, and commit/push authorized changes to hoshixdd/REI. Report tested behavior and remaining limitations accurately.
5. Before a real public launch, complete cross-browser/performance/accessibility checks and agree on hosting and any backend requirements. GitHub source backup and localhost preview are the current delivery state.

## Spatial studio implementation checkpoint
The user's latest correction explicitly allows improving the strongest homepage graphic too. Do not preserve it unchanged. This release upgrades its sculptural core, all phase graphics, palette, typography, and shared page surfaces.

Local research workflows now exist at `#research` and `#research/<project-id>/<library|map|evidence|proposal>`, implemented in `dist/research.js`. Research data uses IndexedDB `rei-research`, store `projects`; old learning data still uses `rrh-v2`. Both have separate exports. Do not clear either storage system. Paper relationships are manually recorded and are not live provider citations.

Read `RELEASE_NOTES.md` for the full implemented/remaining inventory and `FREE_SETUP.md` for the requested free-account setup. The user has no Supabase/OpenAlex accounts yet and asked for setup files and steps. The SQL migration and Edge Function are prepared, not deployed or integration-tested; cloud sign-in/sync and live search frontend are still unimplemented. Do not claim that credentials alone activate them.

The current local implementation has project and paper editing, notes/status, manual collection labels, a pan/zoom citation map and list, editable evidence with comparison table, source-linked proposal writing, and project backup/restore. More complete collection management, spatial 3D map, cloud workflow, and deeper visual refinement remain. This is a tested local increment, not completion of the entire 70% roadmap.

## Current research depth checkpoint — 26 September 2026
- Implemented the requested free/local improvements across Research Studio without requiring accounts, paid APIs, or cloud services.
- Synthesis matrix: researcher-defined themes with definitions and colors, evidence coding memos, multi-theme rows, safe coding removal, and `rei-synthesis-matrix.csv` export. Evidence rows now show finding/relevance, method/context, limitations, and theme columns.
- Review action queue: generated unresolved prompts from the existing checks plus manual supervisor actions. Prompts can be marked done; manual actions can be completed or removed.
- Source audit: checks source author/year/venue/DOI-or-URL metadata, evidence findings/limitations/confidence/locations, and claim traceability. Exports `rei-source-audit.csv`.
- Method alignment worksheet: objective, measure, population, sample, collection, analysis, ethics, feasibility, expected output, and rationale. Existing design records remain loadable; missing new fields appear as explicit prompts.
- Student starter templates: blank, literature review, survey, interview, and experiment/evaluation. Templates seed a starting question and method plan when creating a project; students can edit or replace every field.
- Supervisor review packet: exports question, open actions, source audit, complete method alignment plan, synthesis themes/coding, comparisons, claims/evidence, student reflection, and bibliography as `rei-supervisor-packet.md`.
- Evidence removal now also respects synthesis coding links. A note must be unlinked from claims, comparisons, and themes before removal.
- Validation: `tests/workbench-core.cjs` passed; `node --check` passed for `dist/research.js`, `dist/workbench-core.js`, and `dist/workbench.js`; `git diff --check` passed. Browser inspection covered the existing project, Synthesis matrix, Review & history, method alignment, starter-template controls, and empty/error prompts. Browser console logs were empty on the inspected routes.
- Full all-route Playwright regression, formal accessibility certification, cross-browser testing, and Vercel production verification remain incomplete. These features are researcher-authored prompts and organization tools, not automatic scientific judgments.

## GitHub and Vercel release checkpoint — 26 September 2026
- GitHub `master` is synchronized with the research-depth release and this deployment checkpoint on `https://github.com/hoshixdd/REI` (feature commit `36b9767`; the handoff metadata was committed immediately after it).
- The current build was deployed with the authenticated Vercel CLI to the existing `probablecause/rei` project on the Hobby plan.
- Production alias: `https://rei-pink.vercel.app`.
- Deployment inspection: `https://vercel.com/probablecause/rei/32swGBoT7ptj7kVkmmz8qdjQXRB9`.
- Verification completed after deployment: the production alias returned HTTP 200; the root page served the REI app; the public `workbench.js?v=rei-research-depth-20260926` asset returned HTTP 200 and contained the supervisor packet and synthesis export implementations.
- Vercel created local `.vercel` and `.env*` ignore rules. No credentials or generated environment files were committed.
- Vercel production is updated for this release. Full all-route regression, formal accessibility certification, cross-browser testing, and performance testing are still pending.
